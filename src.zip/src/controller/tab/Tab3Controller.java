/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.tab;

import controller.MainController;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.util.StringConverter;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

/**
 *
 * @author SB00519010
 */
public class Tab3Controller {

    private MainController main;
      @FXML
LineChart<Double, Double> chart1;
      
      @FXML
      ScatterChart<Double, Double> scatter;
      @FXML
      Label welcome;
      
      @FXML
      Label pvmlabel;
       @FXML
      Label noofscm;
        @FXML
      Label noofscmvalue;
        @FXML
      Label xy;
        @FXML
      Label randlabel;
      @FXML
      ComboBox selectpvm;
      @FXML
      ComboBox randchoice;
      @FXML
      ComboBox xyvalue;
      @FXML
      Button ynumplot;
      @FXML
      Button   vectornoplot;
      @FXML
      Button   yvsrmsplot;
      @FXML
      TextArea  pvmeq;
      @FXML
      NumberAxis kl;
      
      
     

    List<String> paths = new ArrayList<String>();
    List<String> pvmlines2 = new ArrayList<String>();
    List<String> pvmlines = new ArrayList<String>();
    List<String> sublines = new ArrayList<String>();
    List<String> sublinesl = new ArrayList<String>();
    List<String> sublinesr = new ArrayList<String>();
    List<String> temp = new ArrayList<String>();
    
    String[][] arr=new String[100][0];
    List<Double> vector = new ArrayList<Double>();
    List<Double> yvalues = new ArrayList<Double>();
    List<String> xyselectvalues = new ArrayList<String>();

    public void getFilePath(List<File> file) {
        welcome.setVisible(false);
        // System.out.println(file.get(0).getPath());
        for (int i = 0; i < file.size(); i++) {
            //System.out.println(file.get(i).getPath());
            paths.add(file.get(i).getPath());
            System.out.println(file.get(i).getParent());

        }
        randchoice.getItems().add("100");
        randchoice.getItems().add("10");
        randchoice.getItems().add("1");
        randchoice.getItems().add("0.1");
        randchoice.getItems().add("0.01");
        
        
        
        comboSelections();
        main();
    }

    private void comboSelections() {

        for (int i = 0; i < paths.size(); i++) {
            String line;
            File f = new File(paths.get(i));
            if (f.getName().contains("unrol")) {
                try {
                    BufferedReader reader = new BufferedReader(new FileReader(paths.get(i)));
                    while ((line = reader.readLine()) != null) {
                        
                        if(line.startsWith("g_pvm")){
                            pvmlines2.add(line);
                        line = line.replaceAll(" ", "").replaceAll(";", "");
                        pvmlines.add(line);
                        String[] parts = line.split("=", 2);
                        if (parts.length >= 2) {
                            String key = parts[0];
                            String value = parts[1];
                          //System.out.println(key);
                           selectpvm.getItems().add(key);
                            sublinesl.add(key);
                            //selectpvm.getItems().add(key);
                            sublinesr.add(value);
                        }
                        }
                    }
                } catch (IOException s) {
                    //System.out.println("Error, could not read file"); 

                }
            }
        }

    }
    
    private void main() {
        
        selectpvm.setVisible(true);
         pvmlabel.setVisible(true);
        pvmeq.setStyle("-fx-control-inner-background:#000000; -fx-font-family: Consolas; -fx-highlight-fill: #00ff00; -fx-highlight-text-fill: #000000; -fx-text-fill: #00ff00; ");
        
         //pvmeq.setFill(Color.RED);
        
        
        List<Double> xvalues= new ArrayList<Double>();
        
        
        for (int i = 0; i < 100; i++) {
            List<String> temp = new ArrayList<String>();
            Pattern p1 = Pattern.compile("g_scm\\[\\w+\\]");
            Matcher m1 = p1.matcher(pvmlines.get(i));
            while (m1.find()) {
                temp.add(m1.group());
                //System.out.println("check"+m1.group());
            }
            String pvmold = pvmlines.get(i);
            //System.out.println("check"+pvmold);
            for (int j = 0; j < temp.size(); j++) {
                String scms = temp.get(j).replace("[", "\\[").replace("]", "\\]");
                //System.out.println("check"+scms);
                float ran = randFloat(0, 100);
                pvmold = pvmold.replaceAll(scms, String.valueOf(ran));
                

                //System.out.println("check"+scms);
            }
            
            String split[] = pvmold.split("=");
                ScriptEngineManager factory = new ScriptEngineManager();
                // create a JavaScript engine
                ScriptEngine engine = factory.getEngineByName("JavaScript");
                // evaluate JavaScript code from String
                try {
                    Object obj = engine.eval(split[1]);
                    //xvalues.add(Double.valueOf((String)obj));
                   // System.out.println(obj.getClass());
                   // System.out.println(((Double)obj));
                    xvalues.add((Double)obj);
                    
                } catch (Exception s) {
                    System.out.println("Error, could not parse"); 

                }
                
                
              
            //System.out.println("check" + xvalues.get(i));
        }
        
         XYChart.Series<Number, Double> series1 = new XYChart.Series<Number, Double>();
         series1.setName("PLOT");
   // series1.setName("Series 1");
   // series1.getData().add(new XYChart.Data<>(1, 20.0));
   // series1.getData().add(new XYChart.Data<>(2, 100.9));
   // series1.getData().add(new XYChart.Data<>(3, 80.5));
   // series1.getData().add(new XYChart.Data<>(4, 180.7));
   // series1.getData().add(new XYChart.Data<>(5, 20.4));
   // series1.getData().add(new XYChart.Data<>(6, -10.5));
    //chart1.getData().add(series1);
       
    //chart1.getData().add(series);
     //  for(int k=0;k<xvalues.size();k++){
           
          // series1.getData().add(new XYChart.Data<>(k, xvalues.get(k)));
      //// }
       //chart1.getData().add(series1);
    }
    
     @FXML private void onpvmselect(ActionEvent event) {
         randlabel.setVisible(true);
         randchoice.setVisible(true);
         scatter.setVisible(false);
         int aa = selectpvm.getSelectionModel().getSelectedIndex();
          pvmeq.setText(pvmlines2.get(aa));
    }
     
     
     @FXML private void onrandchoice(ActionEvent event) {
         temp.clear();
         vector.clear();
         yvalues.clear();
         xyselectvalues.clear();
         xyvalue.getItems().clear() ;
          scatter.setVisible(false);
        
        int aa = selectpvm.getSelectionModel().getSelectedIndex();
        String random = randchoice.getSelectionModel().getSelectedItem().toString();
        System.out.println(random);
        Pattern p1 = Pattern.compile("g_scm\\[\\w+\\]");
            Matcher m1 = p1.matcher(pvmlines.get(aa));
            while (m1.find()) {
                temp.add(m1.group());
                //System.out.println("check"+m1.group());
            }
            temp = temp.stream().distinct().collect(Collectors.toList());
            for(int x=0;x<temp.size();x++){
                int c =x+1;
                xyselectvalues.add("Y vs S"+c);
                
            }
            xyvalue.getItems().addAll(xyselectvalues);
            
            arr = new String[100][temp.size()];
            for (int z=0; z<temp.size();z++){
            for(int r=0;r<100;r++){
                
                float ran = randFloat(0, Float.valueOf((random)));
                arr[r][z]=temp.get(z)+","+Float.valueOf(ran);
               // System.out.println(temp.get(z)+","+String.valueOf(ran));
            }}
            
            for(int c =0;c<100;c++){
                float tt =0.0f;
            for (int zz=0; zz<temp.size();zz++){
            
                
                String[] gh = arr[c][zz].split(",");
                float v = Float.parseFloat(gh[1]) * Float.parseFloat(gh[1]) ;
                tt = tt + v;
                
            } 
            vector.add(((Math.sqrt(tt)))/2);
             //System.out.println(((float)(Math.sqrt(tt)))/2);
            }
            
            /////////////////////////////////
            
            for(int c =0;c<100;c++){
                String jk = pvmlines.get(aa);
            for (int zz=0; zz<temp.size();zz++){
             String[] gh = arr[c][zz].split(",");

                 String scms = gh[0].replace("[", "\\[").replace("]", "\\]");
                //System.out.println("check"+scms);
               // float ran = randFloat(0, 100);
                jk = jk.replaceAll(scms, gh[1]);
        //System.out.println("jkues"+jk); 
            }
            String split[] = jk.split("=");
                ScriptEngineManager factory = new ScriptEngineManager();
                // create a JavaScript engine
                ScriptEngine engine = factory.getEngineByName("JavaScript");
                // evaluate JavaScript code from String
                try {
                    Object obj = engine.eval(split[1]);
                    yvalues.add(((Double)obj));
                    // System.out.println("yvalues"+(Math.sqrt((Double)obj))); 
                    
                } catch (Exception s) {
                    System.out.println("Error, could not parse"); 

                }
                
            
       
            }
            
            
         /*    NumberFormat format = new DecimalFormat("#.#E0");
    kl.setTickLabelFormatter(new StringConverter<Number>() {

        @Override
        public String toString(Number number) {
            return format.format(number.doubleValue());
        }

        @Override
        public Number fromString(String string) {
            try {
                return format.parse(string);
            } catch (ParseException e) {
                e.printStackTrace();
                return 0 ;
            }
        }

    });*/
            
            
        pvmeq.setText(pvmlines2.get(aa));
        noofscmvalue.setText(String.valueOf(temp.size()));
        noofscm.setVisible(true);
        noofscmvalue.setVisible(true);
        xy.setVisible(true);
        xyvalue.setVisible(true);
        ynumplot.setVisible(true);
        vectornoplot.setVisible(true);
        yvsrmsplot.setVisible(true);
        pvmeq.setVisible(true);
     }
     
     
     
     
     
     
     
     
     
     
     
     @FXML private void onxyselect(ActionEvent event) {
         
         
         
         
         
         
         
         
         
         
         
         
         scatter.getData().clear();
         int aa = xyvalue.getSelectionModel().getSelectedIndex();
         String bb= pvmlines.get(aa);
         XYChart.Series<Double, Double> series1 = new XYChart.Series<Double, Double>();
            series1.setName("S VS Y ");
         for (int i = 0; i < 100; i++) {
             // chart1 = new  LineChart<Double,Double> ;
             
             // `arr[i][aa] = 
            
            String[] gh = arr[i][aa].split(",");
            System.out.println(Double.parseDouble(gh[1]));
            System.out.println(yvalues.get(i));
            series1.getData().add(new XYChart.Data<>(Double.parseDouble(gh[1]),yvalues.get(i)));
            
                     
                     
                     }
         scatter.getData().add(series1);         
            scatter.setVisible(true);
         
     }
     @FXML private void ynoaction(ActionEvent event) {
         
           scatter.getData().clear();
         
         XYChart.Series<Double, Double> series1 = new XYChart.Series<Double, Double>();
            series1.setName("NO OF POINTS VS Y");
         for (int i = 0; i < 100; i++) {
            
            series1.getData().add(new XYChart.Data<>((double)(i),yvalues.get(i)));
            
                     
                     
                     }
         scatter.getData().add(series1);         
           scatter.setVisible(true);
         
     }
     
     
     @FXML private void vectaction(ActionEvent event) {
         
           scatter.getData().clear();
         
         XYChart.Series<Double, Double> series1 = new XYChart.Series<Double, Double>();
            series1.setName("NO OF POINTS VS VECTOR");
         for (int i = 0; i < 100; i++) {
            
            series1.getData().add(new XYChart.Data<>((double)(i),vector.get(i)));
            
                     
                     
                     }
         scatter.getData().add(series1);         
            scatter.setVisible(true);
         
     }
     
     @FXML private void yvectaction(ActionEvent event) {
         
          scatter.getData().clear();
         
         XYChart.Series<Double, Double> series1 = new XYChart.Series<Double, Double>();
            series1.setName("VECTOR VS Y");
         for (int i = 0; i < 100; i++) {
            
            series1.getData().add(new XYChart.Data<>(vector.get(i),yvalues.get(i)));
            
                     
                     
                     }
         scatter.getData().add(series1);         
           scatter.setVisible(true);
         
     }
       

    public void init(MainController mainController) {
        main = mainController;
    }

    public static float randFloat(float min, float max) {

        Random rand = new Random();

        float result = rand.nextFloat() * (max - min) + min;

        return result;

    }
}
