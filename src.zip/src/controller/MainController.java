package controller;

import javafx.fxml.FXML;
import controller.tab.Tab3Controller;
import controller.tab.Tab4Controller;

import java.io.File;
import java.util.List;
import javafx.scene.control.TabPane;

public class MainController {
        @FXML Tab3Controller tab3Controller;
        @FXML Tab4Controller tab4Controller;
     
        
        @FXML private TabPane  tabpane;
        
        
       
	
	@FXML public void initialize() {
		System.out.println("Application started");
                tab3Controller.init(this);
                tab4Controller.init(this);
              
	}



	
        public void setFilePath(List<File> file){
            //System.out.println(file.get(0).getPath());
            tab3Controller.getFilePath(file);
            
        }        //}
}
